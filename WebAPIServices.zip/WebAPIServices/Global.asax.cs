﻿using AutoMapper;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Http;
using System.Web.Routing;
using ConsumeWebAPI.Models;

namespace ConsumeWebAPI
{
    public class WebApiApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            GlobalConfiguration.Configure(WebApiConfig.Register);

            var config = new MapperConfiguration(cfg => {
                cfg.CreateMap<Person, Person>();
            });

            IMapper mapper = config.CreateMapper();
            var source = new Person();
            var dest = mapper.Map<Person, Person>(source);
        }
    }
}
