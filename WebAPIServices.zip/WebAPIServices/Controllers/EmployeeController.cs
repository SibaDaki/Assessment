﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace WebAPIServices.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee

        [Route("api/employee")]
        [HttpGet]
        public JsonResult<List<Models.Employee>> GetAllEmployee()
        {
            EntityMapper<DataLayer.Employee, Models.Employee> mapObj = new EntityMapper<DataLayer.Employee, Models.Employee>();

            DataLayer.Employee employeeList = DAL.GetEmployee(id);
            Models.Employee employees = new Models.Employee();
            employee = mapObj.Translate(employeeList);
            return Json<Models.Employee>(employee);
        }

        [HttpGet]
        public JsonResult<Models.Employee> GetEmployee(int id)
        {
            EntityMapper<DataLayer.Employee, Models.Employee> mapObj = new EntityMapper<DataLayer.Employee, Models.Employee>();

            DataLayer.Employee empList = DAL.GetEmployee(id);
            Models.Employee people = new Models.Employee();
            people = mapObj.Translate(empList);
            return Json<Models.Employee>(people);
        }
        
        //Insert Employee
        [HttpPost]
        public bool InsertEmployee(Models.Employee employee)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                EntityMapper<Models.Employee, DataLayer.Employee> mapObj = new EntityMapper<Models.Employee, DataLayer.Employee>();
                DataLayer.Employee empObj = new DataLayer.Employee();
                empObj = mapObj.Translate(employee);
                status = DAL.InsertEmployee(empObj);
            }
            return status;

        }
       
        [HttpPut]
        public bool UpdateEmployee(Models.Employee employee)
        {
            EntityMapper<Models.Employee, DataLayer.Employee> mapObj = new EntityMapper<Models.Employee, DataLayer.Employee>();
            DataLayer.Person empObj = new DataLayer.Person();
            empObj = mapObj.Translate(employee);
            var status = DAL.UpdatePerson(empObj);
            return status;

        }
        [HttpDelete]
        public bool DeleteEmployee(int id)
        {
            var status = DAL.DeleteEmployee(id);
            return status;
        }
    }
}