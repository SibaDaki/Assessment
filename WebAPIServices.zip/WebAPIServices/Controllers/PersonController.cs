﻿using System.Collections.Generic;
using System.Web.Http;
using System.Web.Http.Results;
using ConsumeWebAPI.Repository;



namespace ConsumeWebAPI.Controllers
{
    public class PersonController : ApiController
    {
        // GET: Person and Employee 
        [Route("api/employee")]
        [HttpGet]
        public JsonResult<List<Models.Person>> GetAllPerson()
        {
            EntityMapper<DataLayer.Person, Models.Person> mapObj = new EntityMapper<DataLayer.Person, Models.Person>();

            DataLayer.Person person = DALS.GetPerson(id);
            Models.Person people = new Models.Person();
            people = mapObj.Translate(person);
            return Json(people);
        }
        //Get Employee
        [HttpGet]
        public JsonResult<List<Models.Employee>> GetAllEmployee()
        {
            EntityMapper<DataLayer.Employee, Models.Employee> mapObj = new EntityMapper<DataLayer.Employee, Models.Employee>();

            DataLayer.Employee employeeList = DAL.GetEmployee(id);
            Models.Employee employees = new Models.Employee();
            employee = mapObj.Translate(employeeList);
            return Json<Models.Employee>(employee);
        }
        
        [HttpGet]
        public JsonResult<Models.Person> GetPerson (int id)
        {
            EntityMapper<DataLayer.Person, Models.Person> mapObj = new EntityMapper<DataLayer.Person, Models.Person>();

            DataLayer.Person person = DAL.GetPerson(id);
            Models.Person people = new Models.Person();
            people = mapObj.Translate(person);
            return Json(people);
        }
        //EMployee
        [HttpGet]
        public JsonResult<Models.Employee> GetEmployee(int id)
        {
            EntityMapper<DataLayer.Employee, Models.Employee> mapObj = new EntityMapper<DataLayer.Employee, Models.Employee>();

            DataLayer.Employee empList = DAL.GetEmployee(id);
            Models.Employee people = new Models.Employee();
            people = mapObj.Translate(empList);
            return Json<Models.Employee>(people);
        }
        [HttpPost]
        public bool InsertPerson(Models.Person person)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                EntityMapper<Models.Person, DataLayer.Person> mapObj = new EntityMapper<Models.Person, DataLayer.Person>();
                DataLayer.Person personObj = new DataLayer.Person();
                personObj = mapObj.Translate(person);
                status = DAL.InsertPerson(personObj);
            }
            return status;

        }
        //Insert Employee
        [HttpPost]
        public bool InsertEmployee(Models.Employee employee)
        {
            bool status = false;
            if (ModelState.IsValid)
            {
                EntityMapper<Models.Employee, DataLayer.Employee> mapObj = new EntityMapper<Models.Employee, DataLayer.Employee>();
                DataLayer.Employee empObj = new DataLayer.Employee();
                empObj = mapObj.Translate(employee);
                status = DAL.InsertEmployee(empObj);
            }
            return status;

        }
        [HttpPut]
        public bool UpdatePerson(Models.Person person)
        {
            EntityMapper<Models.Person, DataLayer.Person> mapObj = new EntityMapper<Models.Person, DataLayer.Person>();
            DataLayer.Person personObj = new DataLayer.Person();
            personObj = mapObj.Translate(person);
            var status = DAL.UpdatePerson(personObj);
            return status;

        }

        [HttpPut]
        public bool UpdateEmployee(Models.Employee employee)
        {
            EntityMapper<Models.Employee, DataLayer.Employee> mapObj = new EntityMapper<Models.Employee, DataLayer.Employee>();
            DataLayer.Person empObj = new DataLayer.Person();
            empObj = mapObj.Translate(employee);
            var status = DAL.UpdatePerson(empObj);
            return status;

        }
        [HttpDelete]
        public bool DeletePerson(int id)
        {
            var status = DAL.DeletePreson(id);
            return status;
        }
    }
}
