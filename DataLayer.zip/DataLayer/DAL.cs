﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataLayer
{
    public  class DAL
    {
        static masterEntities DbContext;
        static DAL()
        {
            DbContext = new masterEntities();
        }
        //Person
        public static List<Person> GetAllPerson()
        {
            return DbContext.People.ToList();
                
        }

        //Employees
        public static List<Employee> GetAllEmployee()
        {
            return DbContext.Employee.ToList();

        }

        //Person
        public static Person GetPerson(int personId)
        {
            return DbContext.People.Where(p => p.PersonId == personId).FirstOrDefault();
        }
        public static bool InsertPerson(Person person)
        {
            bool status;
            try
            {
                DbContext.People.Add(person);
                DbContext.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //Employee
        public static Employee GetEmployee(int employeeId)
        {
            return DbContext.Employee.Where(p => p.EmployeeId == employeeId).FirstOrDefault();
        }
        public static bool InsertEployee(Employee employee)
        {
            bool status;
            try
            {
                DbContext.Employee.Add(employee);
                DbContext.SaveChanges();
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //Person
        public static bool UpdatePerson(Person person)
        {
            bool status;
            try
            {
                Person pers = DbContext.People.Where(p => p.PersonId == person.PersonId).FirstOrDefault();
                if (pers != null)
                {
                    pers.LastName = person.LastName;
                    pers.FirstName = person.FirstName;
                    pers.BirthDate = person.BirthDate;
                    pers.EmployeePersonId = person.EmployeePersonId;
                    DbContext.SaveChanges();
                }
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //Employee
        public static bool UpdateEmployee(Employee employee)
        {
            bool status;
            try
            {
                Employee employees = DbContext.Employee.Where(p => p.EmployeeId == employee.EmployeeId).FirstOrDefault();
                if (employees != null)
                {
                    employees.PersonId = employee.PersonId;
                    employees.EmployeeNo = employee.EmployeeNo;
                    employees.EmployeeDate = employee.EmployeeDate;
                    employees.TerminatedDate = employee.TerminatedDate;
                    DbContext.SaveChanges();
                }
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }

        //Person
        public static bool DeletePerson(int id)
        {
            bool status;
            try
            {
                Person pers = DbContext.People.Where(p => p.PersonId == id).FirstOrDefault();
                if (pers != null)
                {
                    DbContext.People.Remove(pers);
                    DbContext.SaveChanges();
                }
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }


        //Employee
        public static bool DeleteEmployee(int id)
        {
            bool status;
            try
            {
                Employee employee = DbContext.Employee.Where(p => p.EmployeeId == id).FirstOrDefault();
                if (employee != null)
                {
                    DbContext.Employee.Remove(employee);
                    DbContext.SaveChanges();
                }
                status = true;
            }
            catch (Exception)
            {
                status = false;
            }
            return status;
        }
    }
}