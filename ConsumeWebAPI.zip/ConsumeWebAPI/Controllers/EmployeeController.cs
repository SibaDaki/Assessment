﻿using ConsumeWebAPI.Models;
using ConsumeWebAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace ConsumeWebAPI.Controllers
{
    public class EmployeeController : Controller
    {
        // GET: Employee
        [Route("Employee")]
        public ActionResult GetAllEmployee()
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.GetResponse("api/employee/getallemployee");
                response.EnsureSuccessStatusCode();
                List<Models.Person> employees = response.Content.ReadAsAsync<List<Models.Person>>().Result;
                ViewBag.Title = "All People";
                return View(employees);
            }
            catch (Exception)
            {
                throw;
            }
        }

        //[HttpGet]  
        [Route("Employee/{id?}")]
        public ActionResult EditEmployee(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/employee/GetEmployee?id=-1" + id.ToString());
            response.EnsureSuccessStatusCode();
            Employee employee = response.Content.ReadAsAsync<Employee>().Result;
            ViewBag.Title = "All People";
            return View(employee);
        }
        // GET: Employees/Edit/5
        //public ActionResult Edit(int? id)
        //{
        //    if (id == null)
        //    {
        //        return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
        //    }
        //    // Employee employee = db.Employee.Find(id);
        //    Employee employee = new Employee();
        //    if (employee == null)
        //    {
        //        return HttpNotFound();
        //    }
        //    return View(employee);
        //}


        [HttpPost, ActionName("Index")]
        public ActionResult UpdateEmployee(Models.Employee employee)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.PutResponse("api/employee/UpdateEmployee", employee);
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllEmployee");
        }

        public ActionResult DetailEmployee(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/employee/GetEmployee?id=" + id.ToString());
            response.EnsureSuccessStatusCode();
            Models.Employee employee = response.Content.ReadAsAsync<Models.Employee>().Result;
            ViewBag.Title = "All Employee";
            return View(employee);

        }

        [HttpPost, ActionName("Index")]
        public ActionResult CreateEmployee(Models.Employee employee)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.PostResponse("api/employee/InsertEmployee", employee);
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllEmployee");
        }

        public ActionResult DeleteEmployee(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.DeleteResponse("api/employee/DeleteEmployee?id=" + id.ToString());
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllEmployee");
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }

        //[HttpPost]
        //public ActionResult Edit(int? id)
        //{

        //  return View();
        //}

    }
}