﻿using ConsumeWebAPI.Repository;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Web;
using System.Web.Mvc;

namespace ConsumeWebAPI.Controllers
{
    public class PeopleController : Controller
    {
        // GET: Person  
        public ActionResult GetAllPerson()
        {
            try
            {
                ServiceRepository serviceObj = new ServiceRepository();
                HttpResponseMessage response = serviceObj.GetResponse("api/person/getallperson");
                response.EnsureSuccessStatusCode();
                List<Models.Person> people = response.Content.ReadAsAsync<List<Models.Person>>().Result;
                ViewBag.Title = "All People";
                return View(people);
            }
            catch (Exception)
            {
                throw;
            }
        }

        
        //[HttpGet]  
        public ActionResult EditPerson(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/person/GetEmployee?id=" + id.ToString());
            response.EnsureSuccessStatusCode();
            Models.Person person = response.Content.ReadAsAsync<Models.Person>().Result;
            ViewBag.Title = "All People";
            return View(person);
        }

       
        //[HttpPost]  
        public ActionResult UpdatePerson(Models.Person person)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.PutResponse("api/person/UpdatePerson", person);
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllPerson");
        }

      
        public ActionResult Details(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/employee/GetPerson?id=" + id.ToString());
            response.EnsureSuccessStatusCode();
            Models.Person person = response.Content.ReadAsAsync<Models.Person>().Result;
            ViewBag.Title = "All Person";
            return View(person);

        }
        public ActionResult DetailEmployee(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.GetResponse("api/person/GetEmployee?id=" + id.ToString());
            response.EnsureSuccessStatusCode();
            Models.Employee employee = response.Content.ReadAsAsync<Models.Employee>().Result;
            ViewBag.Title = "All Employee";
            return View(employee);

        }
        [HttpGet]
        public ActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public ActionResult CreatePerson(Models.Person person)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.PostResponse("api/person/InsertPerson", person);
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllPerson");
        }
        
        public ActionResult DeletePerson(int id)
        {
            ServiceRepository serviceObj = new ServiceRepository();
            HttpResponseMessage response = serviceObj.DeleteResponse("api/person/DeletePerson?id=" +  id.ToString());
            response.EnsureSuccessStatusCode();
            return RedirectToAction("GetAllPerson");
        }
       
    }
}            