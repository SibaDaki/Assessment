﻿using System;
using System.Web;
using System.ComponentModel.DataAnnotations.Schema;
using System.Collections.Generic;
using DataLayer;

namespace ConsumeWebAPI.Models
{   //[Table("Person")]
    public class Employee : Person
    {
        
        public int EmployeeId { set; get; }
        [ForeignKey ("PersonId")]
        public new int PersonId { set; get; }
        public string EmployeeNo { set; get; }
        public DateTime EmployeeDate { set; get; }
        public DateTime TerminatedDate { set; get; }

        public  List<Person> Persons { set; get; }

    }
}
