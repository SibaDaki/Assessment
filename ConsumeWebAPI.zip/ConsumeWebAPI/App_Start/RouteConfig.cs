﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace ConsumeWebAPI
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");

            routes.MapRoute(
                name: "Default",
                url: "{api}/{action}/{id}",
                defaults: new
                { controller = "Empoyee",
                    action = "Index",
                    id = UrlParameter.Optional }
            );
            //routes.MapRoute(
            //    name: "de",
            //    url: "{employee}/{action}/{id}",
            //    defaults: new { controller = "employee", action = "Index", id = UrlParameter.Optional }
            //);
        }
    }
}
